import cv2
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from random import shuffle
plt.rcParams['figure.figsize'] = [8,8]

def drawfig(image_dir='wgan_gp_conv_val',title='Sample Results'):
    imgnames = os.listdir(image_dir)
    shuffle(imgnames)
    combine = np.zeros((28*5, 28*5),dtype=np.uint8)
    for i in range(25):
        img = cv2.imread('%s/%s' % (image_dir,imgnames[i]),0)
        combine[(i//5)*28:(i//5+1)*28,(i%5)*28:(i%5+1)*28] = img
    plt.axis('off')
    plt.title(title, fontsize=20)
    plt.imshow(combine, cmap='gray', vmin=0,vmax=255)
    plt.show()

def draw25imgs(imgs):
    combine = np.zeros((28 * 5, 28 * 5), dtype=np.uint8)
    for i in range(25):
        img = imgs[i]
        combine[(i//5)*28:(i//5+1)*28,(i%5)*28:(i%5+1)*28] = img
    plt.axis('off')
    plt.title('Sample Fashion MNIST data', fontsize=20)
    plt.imshow(combine, cmap='gray', vmin=0,vmax=255)
    plt.show()