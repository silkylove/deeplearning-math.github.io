'''
Credit: https://github.com/wiseodd/generative-models
'''
import tensorflow as tf
from tensorflow.examples.tutorials.mnist import input_data
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import os
from scipy.misc import imsave


mb_size = 32
X_dim = 784
z_dim = 100
h_dim = 128
lam = 10
lr = 1e-4
MAX_ITER = 1000000
VALIDATE = True
VALIDATE_DIR = './wgan_gp_val/'
LOGDIR = './wgan_gp_logs/'
OUTDIR = './wgan_gp_out/'

# mnist = input_data.read_data_sets('../MNIST_data', one_hot=True)
fashion_mnist = input_data.read_data_sets('./fashion_mnist_data', source_url='http://fashion-mnist.s3-website.eu-central-1.amazonaws.com/')
print("Fashion MNIST data loaded.")

def preprocess_img(x):
    return 2 * x - 1.0

def deprocess_img(x):
    return (x + 1.0) / 2.0


def plot(samples):
    fig = plt.figure(figsize=(4, 4))
    gs = gridspec.GridSpec(4, 4)
    gs.update(wspace=0.05, hspace=0.05)

    for i, sample in enumerate(samples):
        ax = plt.subplot(gs[i])
        plt.axis('off')
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        ax.set_aspect('equal')
        plt.imshow(sample.reshape(28, 28), cmap='Greys_r')

    return fig


def xavier_init(size):
    in_dim = size[0]
    xavier_stddev = 1. / tf.sqrt(in_dim / 2.)
    return tf.random_normal(shape=size, stddev=xavier_stddev)


X = tf.placeholder(tf.float32, shape=[None, X_dim])

D_W1 = tf.Variable(xavier_init([X_dim, h_dim]))
D_b1 = tf.Variable(tf.zeros(shape=[h_dim]))

D_W2 = tf.Variable(xavier_init([h_dim, 1]))
D_b2 = tf.Variable(tf.zeros(shape=[1]))

theta_D = [D_W1, D_W2, D_b1, D_b2]


z = tf.placeholder(tf.float32, shape=[None, z_dim])

G_W1 = tf.Variable(xavier_init([z_dim, h_dim]))
G_b1 = tf.Variable(tf.zeros(shape=[h_dim]))

G_W2 = tf.Variable(xavier_init([h_dim, X_dim]))
G_b2 = tf.Variable(tf.zeros(shape=[X_dim]))

theta_G = [G_W1, G_W2, G_b1, G_b2]


def sample_z(m, n):
    return np.random.uniform(-1., 1., size=[m, n])


def G(z):
    with tf.variable_scope('generator'):
        G_h1 = tf.nn.relu(tf.matmul(z, G_W1) + G_b1)
        G_log_prob = tf.matmul(G_h1, G_W2) + G_b2
        G_prob = tf.nn.tanh(G_log_prob)
        return G_prob


def D(X):
    with tf.variable_scope('discriminator'):
        D_h1 = tf.nn.relu(tf.matmul(X, D_W1) + D_b1)
        out = tf.matmul(D_h1, D_W2) + D_b2
        return out


G_sample = G(z)
with tf.variable_scope("") as scope:
    logits_real = D(preprocess_img(X))
    # Re-use discriminator weights on new inputs
    scope.reuse_variables()
    logits_fake = D(G_sample)

eps = tf.random_uniform([mb_size, 1], minval=0., maxval=1.)
x_hat = eps*X + (1. - eps)*G_sample
with tf.variable_scope('', reuse=True) as scope:
    grad_D_x_hat = tf.gradients(ys=D(preprocess_img(x_hat)), xs=x_hat)[0]
grad_norm = tf.sqrt(tf.reduce_sum((grad_D_x_hat)**2, axis=1))
grad_pen = lam * tf.reduce_mean((grad_norm - 1)**2)

D_loss = tf.reduce_mean(logits_fake) - tf.reduce_mean(logits_real) + grad_pen
G_loss = -tf.reduce_mean(logits_fake)

D_solver = (tf.train.AdamOptimizer(learning_rate=lr, beta1=0.5)
            .minimize(D_loss, var_list=theta_D))
G_solver = (tf.train.AdamOptimizer(learning_rate=lr, beta1=0.5)
            .minimize(G_loss, var_list=theta_G))

sess = tf.Session()
sess.run(tf.global_variables_initializer())
saver = tf.train.Saver(max_to_keep=3)
if not os.path.exists(LOGDIR):
    os.makedirs(LOGDIR)
ckpt = tf.train.get_checkpoint_state(LOGDIR)
start_itr = 0
if ckpt and ckpt.model_checkpoint_path:
    saver.restore(sess, ckpt.model_checkpoint_path)
    print("Restoring from ", ckpt.model_checkpoint_path)
    start_itr = int(ckpt.model_checkpoint_path.split('-')[1])
    print("Starting from iteration ", start_itr)


if not os.path.exists(OUTDIR):
    os.makedirs(OUTDIR)

i = 0

if VALIDATE:
    if not os.path.exists(VALIDATE_DIR):
        os.makedirs(VALIDATE_DIR)
    val_size = 1000
    samples = sess.run(G_sample, feed_dict={z: sample_z(val_size, z_dim)})
    samples = np.reshape(samples, (-1, 28, 28))
    samples = deprocess_img(samples)
    for i in range(val_size):
        imsave(VALIDATE_DIR + str(i) + '.png', samples[i])
    quit()

if start_itr < MAX_ITER:
    for it in range(start_itr, MAX_ITER):
        X_mb, _ = fashion_mnist.train.next_batch(mb_size)

        _, D_loss_curr = sess.run(
            [D_solver, D_loss],
            feed_dict={X: X_mb, z: sample_z(mb_size, z_dim)}
        )

        _, G_loss_curr = sess.run(
            [G_solver, G_loss],
            feed_dict={z: sample_z(mb_size, z_dim)}
        )

        if it % 2000 == 0:
            print('Iter: {}; D loss: {:.4}; G_loss: {:.4}'.format(it, D_loss_curr, G_loss_curr))

            samples = sess.run(G_sample, feed_dict={z: sample_z(64, z_dim)})
            samples = np.reshape(samples,(-1,28,28))
            samples = deprocess_img(samples)
            for i in range(64):
                imsave(OUTDIR + str(it)+'_'+str(i)+'.png',samples[i])



            saver.save(sess, LOGDIR + "model.ckpt", global_step=it)