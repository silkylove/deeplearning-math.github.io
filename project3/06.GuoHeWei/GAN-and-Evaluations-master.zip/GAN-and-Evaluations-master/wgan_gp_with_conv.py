import tensorflow as tf
from tensorflow.examples.tutorials.mnist import input_data
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import os
from scipy.misc import imsave

mb_size = 32
X_dim = 784
z_dim = 100
h_dim = 128
lam = 10
n_disc = 5
lr = 1e-4
MAX_ITER = 1000000
VALIDATE = True
VALIDATE_DIR = './wgan_gp_conv_val/'
LOGDIR = './wgan_gp_conv_logs2/'
OUTDIR = './wgan_gp_conv_out2/'

# mnist = input_data.read_data_sets('../MNIST_data', one_hot=True)
fashion_mnist = input_data.read_data_sets('./fashion_mnist_data',
                                          source_url='http://fashion-mnist.s3-website.eu-central-1.amazonaws.com/')
print("Fashion MNIST data loaded.")


def plot(samples):
    fig = plt.figure(figsize=(4, 4))
    gs = gridspec.GridSpec(4, 4)
    gs.update(wspace=0.05, hspace=0.05)

    for i, sample in enumerate(samples):
        ax = plt.subplot(gs[i])
        plt.axis('off')
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        ax.set_aspect('equal')
        plt.imshow(sample.reshape(28, 28), cmap='Greys_r')

    return fig


def preprocess_img(x):
    return 2 * x - 1.0

def deprocess_img(x):
    return (x + 1.0) / 2.0

X = tf.placeholder(tf.float32, shape=[None, X_dim])
z = tf.placeholder(tf.float32, shape=[None, z_dim])

def sample_z(m, n):
    return np.random.uniform(-1., 1., size=[m, n])

def G(z):
    # The generator used in DCGAN
    # results should be 784-dim.
    with tf.variable_scope("generator"):
        fc1 = tf.layers.dense(z, units=1024, activation=tf.nn.relu)
        bn1 = tf.layers.batch_normalization(fc1, training=True)
        fc2 = tf.layers.dense(bn1, units=7 * 7 * 128, activation=tf.nn.relu)
        bn2 = tf.layers.batch_normalization(fc2, training=True)
        resize = tf.reshape(bn2, [-1, 7, 7, 128])
        deconv1 = tf.layers.conv2d_transpose(
            inputs=resize,
            filters=64,
            kernel_size=4,
            strides=(2, 2),
            activation=tf.nn.relu, padding='same',name='g_conv1')
        bn3 = tf.layers.batch_normalization(deconv1, training=True)
        img = tf.layers.conv2d_transpose(inputs=bn3, filters=1, strides=(2, 2), kernel_size=4, activation=tf.nn.tanh,
                                         padding='same',name='g_conv2')
        return tf.reshape(img,[-1,784])


def D(x):
    with tf.variable_scope('discriminator'):
        img = tf.reshape(x, [-1, 28, 28, 1])
        conv1 = tf.layers.conv2d(
            inputs=img,
            filters=64,
            kernel_size=[4, 4],
            strides=(2, 2),
            padding='valid',
            activation=tf.nn.leaky_relu,
            kernel_initializer=tf.truncated_normal_initializer(stddev=0.1),name='d_conv1')
        conv2 = tf.layers.conv2d(
            inputs=conv1,
            filters=128,
            kernel_size=[4, 4],
            strides=(2, 2),
            padding='valid',
            activation=tf.nn.leaky_relu,
            kernel_initializer=tf.truncated_normal_initializer(stddev=0.1),name='d_conv2')
        bn1 = tf.layers.batch_normalization(conv2, training=True)
        reshape = tf.reshape(bn1, [-1, 5 * 5 * 128])
        fc1 = tf.layers.dense(reshape, units=1024, activation=tf.nn.leaky_relu)
        logits = tf.layers.dense(fc1, units=1)
        return logits


G_sample = G(z)
with tf.variable_scope("") as scope:
    logits_real = D(preprocess_img(X))
    # Re-use discriminator weights on new inputs
    scope.reuse_variables()
    logits_fake = D(G_sample)


eps = tf.random_uniform([mb_size, 1], minval=0., maxval=1.)
x_hat = eps*X + (1. - eps)*G_sample
with tf.variable_scope('', reuse=True) as scope:
    grad_D_x_hat = tf.gradients(ys=D(preprocess_img(x_hat)), xs=x_hat)[0]
grad_norm = tf.sqrt(tf.reduce_sum((grad_D_x_hat)**2, axis=1))
grad_pen = lam * tf.reduce_mean((grad_norm - 1)**2)

D_loss = tf.reduce_mean(logits_fake) - tf.reduce_mean(logits_real) + grad_pen
G_loss = -tf.reduce_mean(logits_fake)
theta_D = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES,'discriminator')
theta_G = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES,'generator')
D_solver = (tf.train.AdamOptimizer(learning_rate=lr, beta1=0.5)
            .minimize(D_loss, var_list=theta_D))
G_solver = (tf.train.AdamOptimizer(learning_rate=lr, beta1=0.5)
            .minimize(G_loss, var_list=theta_G))


sess = tf.Session()
sess.run(tf.global_variables_initializer())
saver = tf.train.Saver(max_to_keep=3)
if not os.path.exists(LOGDIR):
    os.makedirs(LOGDIR)
ckpt = tf.train.get_checkpoint_state(LOGDIR)
start_itr = 0
if ckpt and ckpt.model_checkpoint_path:
    saver.restore(sess, ckpt.model_checkpoint_path)
    print("Restoring from ", ckpt.model_checkpoint_path)
    start_itr = int(ckpt.model_checkpoint_path.split('-')[1])
    print("Starting from iteration ", start_itr)

if not os.path.exists(OUTDIR):
    os.makedirs(OUTDIR)

i = 0

if VALIDATE:
    if not os.path.exists(VALIDATE_DIR):
        os.makedirs(VALIDATE_DIR)
    val_size = 1000
    samples = sess.run(G_sample, feed_dict={z: sample_z(val_size, z_dim)})
    samples = np.reshape(samples, (-1, 28, 28))
    samples = deprocess_img(samples)
    for i in range(val_size):
        imsave(VALIDATE_DIR + str(i) + '.png', samples[i])
    quit()

if start_itr < MAX_ITER:
    for it in range(start_itr, MAX_ITER):
        X_mb, _ = fashion_mnist.train.next_batch(mb_size)

        _, D_loss_curr = sess.run(
            [D_solver, D_loss],
            feed_dict={X: X_mb, z: sample_z(mb_size, z_dim)}
        )
        _, G_loss_curr = sess.run(
            [G_solver, G_loss],
            feed_dict={z: sample_z(mb_size, z_dim)}
        )
        if it%10 == 0 :
            print(it)
        if it % 500 == 0:
            print('Iter: {}; D loss: {:.4}; G_loss: {:.4}'.format(it, D_loss_curr, G_loss_curr))

            samples = sess.run(G_sample, feed_dict={z: sample_z(64, z_dim)})
            samples = np.reshape(samples, [-1, 28, 28])
            samples = deprocess_img(samples)
            for i in range(64):
                imsave(OUTDIR + str(it) + '_' + str(i) + '.png', samples[i])

            saver.save(sess, LOGDIR + "model.ckpt", global_step=it)
